const products = [
  { id: 1, name: "Laptop", category: "Electronics", price: 50000, rating: 4.5, img: "images/laptop.jpg" },
  { id: 2, name: "Shirt", category: "Fashion", price: 1200, rating: 4.0, img: "images/shirt.jpg" },
  { id: 3, name: "Book", category: "Books", price: 400, rating: 5.0, img: "images/book.jpg" },
  { id: 4, name: "Headphones", category: "Electronics", price: 2000, rating: 3.8, img: "images/headphones.jpg" }
];
