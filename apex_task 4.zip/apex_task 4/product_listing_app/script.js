const products = [
    { id: 1, name: "Smartphone", category: "Electronics", price: 299, rating: 4.5, image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9" },
    { id: 2, name: "Headphones", category: "Electronics", price: 79, rating: 4.2, image: "https://images.unsplash.com/photo-1583225272822-c7f1e3d89b19" },
    { id: 3, name: "T-Shirt", category: "Clothing", price: 25, rating: 4.0, image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab" },
    { id: 4, name: "Sneakers", category: "Clothing", price: 60, rating: 4.7, image: "https://images.unsplash.com/photo-1519741491158-14a16a92f5a0" },
    { id: 5, name: "Wristwatch", category: "Accessories", price: 120, rating: 4.6, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30" },
    { id: 6, name: "Backpack", category: "Accessories", price: 45, rating: 4.3, image: "https://images.unsplash.com/photo-1505731132164-cca68e34f772" }
];

function displayProducts(items) {
    const productList = document.getElementById('productList');
    productList.innerHTML = '';
    items.forEach(product => {
        const card = document.createElement('div');
        card.classList.add('product-card');
        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>Price: $${product.price}</p>
            <p>Rating: ${product.rating} ⭐</p>
        `;
        productList.appendChild(card);
    });
}

function filterAndSort() {
    let filtered = [...products];

    const category = document.getElementById('categoryFilter').value;
    const price = document.getElementById('priceFilter').value;
    const sort = document.getElementById('sortRating').value;

    if (category !== 'all') {
        filtered = filtered.filter(p => p.category === category);
    }
    if (price !== 'all') {
        const [min, max] = price.split('-').map(Number);
        filtered = filtered.filter(p => {
            if (!max) return p.price >= min;
            return p.price >= min && p.price <= max;
        });
    }
    if (sort === 'high') {
        filtered.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'low') {
        filtered.sort((a, b) => a.rating - b.rating);
    }

    displayProducts(filtered);
}

document.getElementById('categoryFilter').addEventListener('change', filterAndSort);
document.getElementById('priceFilter').addEventListener('change', filterAndSort);
document.getElementById('sortRating').addEventListener('change', filterAndSort);

window.onload = () => displayProducts(products);
